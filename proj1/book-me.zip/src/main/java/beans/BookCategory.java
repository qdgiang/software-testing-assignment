package beans;

public enum BookCategory {
    Art,
    Science,
    Religion,
    History,
    Geography
}
